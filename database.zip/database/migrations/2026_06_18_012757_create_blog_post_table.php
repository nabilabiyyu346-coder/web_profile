<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('blog_post', function(Blueprint $table) {
            $table->id(36);
            $table->string('slug', 150);
            $table->string('image', 150)->unique();
            $table->string('title', 250);
            $table->text('tag');
            $table->text('kilasan');
            $table->longText('content');
            $table->integer('view_count', 11);
            $table->foreignId('id_author', 36);
            $table->timestamp();
            $table->integer('flag', 11);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExist ('blog_post');
    }
};