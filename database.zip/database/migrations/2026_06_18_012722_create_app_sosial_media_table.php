<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('app_sosial_media', function(Blueprint $table) {
            $table->id(11);
            $table->string('icon', 50)->unique();
            $table->string('link', 150)->unique();
            $table->integer('flag', 11);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExist ('app_sosial_media');
    }
};