<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('app_keterampilan', function(Blueprint $table) {
            $table->id(11);
            $table->string('nama_keterampilan', 250);
            $table->integer('nilai', 11);
            $table->integer('flag', 11);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExist ('app_keterampilan');
    }
};