<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('app_lecturer_file', function(Blueprint $table) {
            $table->id(11);
            $table->foreignId('lecture_id', 11)->constrained();
            $table->string('name', 250);
            $table->text('nilai');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExist ('app_lecturer_file');
    }
};