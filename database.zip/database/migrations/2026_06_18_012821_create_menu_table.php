<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('menu', function(Blueprint $table) {
            $table->id(11);
            $table->string('name', 50);
            $table->string('controller',50)->unique();
            $table->string('module', 150)->unique();
            $table->string('action', 50);
            $table->string('icon', 50)->unique();
            $table->integer('order', 11);
            $table->integer('parent_id', 11);
            $table->text('except');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExist ('menu');
    }
};