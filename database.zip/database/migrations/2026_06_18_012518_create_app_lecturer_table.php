<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('app_lecturer', function(Blueprint $table) {
            $table->id(11);
            $table->string('mata_kuliah', 250);
            $table->foreignId('jurusan_id', 11)->constrained();
            $table->year('tahun', 4);
            $table->integer('flag', 11);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExist ('app_lecturer');
    }
};