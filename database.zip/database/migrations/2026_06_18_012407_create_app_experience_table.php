<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('app_experience', function(Blueprint $table) {
            $table->id(11);
            $table->string('name', 250);
            $table->text('description')->nullable();
            $table->integer('start_year', 11);
            $table->integer('end_year', 11);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExist ('app_experience');
    }
};
