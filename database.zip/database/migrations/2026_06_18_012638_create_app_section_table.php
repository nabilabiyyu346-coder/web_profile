<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('app_section', function(Blueprint $table) {
            $table->id(11);
            $table->string('section_name', 150);
            $table->string('compact_data', 150)->unique();
            $table->integer('order', 11)->unique();
            $table->integer('status', 11)->unique();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExist ('app_section');
    }
};